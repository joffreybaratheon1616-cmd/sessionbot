# Bot configuration
# Keep this file private. Do not upload it to a public GitHub repository.

BOT_TOKEN = "8307992523:AAHKphGfGgjEDW4Vc-J80NcXYxj6ZkTAqkI"

API_ID = 31004085
API_HASH = "e589fe8e8037ebc4365a0fca9cd4a04f"

MONGO_URI = "mongodb+srv://aryanaarabh535_db_user:tS7jJKZ6nDLjl6KD@sessionbot.dbjzvxv.mongodb.net/?appName=sessionbot&compressors=zlib"
DB_NAME = "sessionbot"

OWNER_IDS = [5258077200, 6325824692]
